package com.example.walkinclinic;

//Import required packages!
import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.Cursor;

import androidx.annotation.Nullable;

import java.util.ArrayList;

//Made to assist queries and manage databse!
public class DatabaseSQLiteHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "SEG2105";
    private static final String TABLE_NAME = "accounts";
    private static final String COLUMN0 = "ID";
    private static final String COLUMN1 = "username";
    private static final String COLUMN2 = "password";
    private static final String COLUMN3 = "firstName";
    private static final String COLUMN4 = "lastName";
    private static final String COLUMN5 = "phoneNumber";
    private static final String COLUMN6 = "address";
    private static final String COLUMN7 = "email";
    private static final String COLUMN8 = "type";


    private static final String createDatabaseQuery = " CREATE TABLE "+ TABLE_NAME + " ( " + COLUMN0 +" INTEGER PRIMARY KEY AUTOINCREMENT, "+COLUMN1+" TEXT, " + COLUMN2 +" TEXT ," + COLUMN3 +" TEXT ," + COLUMN4 +" TEXT, "+COLUMN5+" TEXT,"+ COLUMN6 +" TEXT, "+ COLUMN7+" TEXT, "+COLUMN8+" TEXT) ";
    private static final String deleteDatabase = "drop table if exists "+TABLE_NAME;

    public DatabaseSQLiteHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //I want to create my database here!
        db.execSQL(createDatabaseQuery);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //DELETE OLD DATABASE
        db.execSQL(deleteDatabase);
        //Create a new one
        onCreate(db);
    }


    //I want to be able to add data and to check if there's any duplicates!
    public boolean insertNewData(String username, String password,String firstName, String lastName, String phoneNumber, String address, String email,String type ) {
        //This will allow me to read and write into database!
        SQLiteDatabase db = this.getWritableDatabase();
        //Create an instance of ContentValues
        ContentValues data = new ContentValues();
        //data.put(COLUMN, VALUE);
        data.put(COLUMN1, username);
        data.put(COLUMN2, password);
        data.put(COLUMN3, firstName);
        data.put(COLUMN4, lastName);
        data.put(COLUMN5, phoneNumber);
        data.put(COLUMN6, address);
        data.put(COLUMN7, email);
        data.put(COLUMN8,type);

        //Now i want to submit this new data into my database
        long insert = db.insert(TABLE_NAME, null, data);

        //If the data WAS NOT successfully added, the value of insert will be -1

        if (insert == -1) {
            return false;
        } else {
            return true;
        }
    }


    //METHODS THAT WILL CHECK IF  E-MAIL OR USERNAME & PHONE NUMBER ARE AVAILABLE!

    public boolean checkAvbEmail(String email){
        //We just want to read from database!
        SQLiteDatabase db = getReadableDatabase();
        //The Query I want to execute!
        Cursor cursor = db.rawQuery("Select * from accounts where email=?",new String[]{email});
        //This will check if there was a result, it will return false, meaning it's already in use!
        if (cursor.getCount()>0){return false;}
        //It will return true if that e-mail is available
        else{return true;}
    }

    public boolean checkAvbPhone(String phoneNum){
        //We just want to read from database!
        SQLiteDatabase db = getReadableDatabase();
        //The Query I want to execute!
        Cursor cursor = db.rawQuery("Select * from accounts where username=?",new String[]{phoneNum});
        //This will check if there was a result, it will return false, meaning it's already in use!
        if (cursor.getCount()>0){return false;}
        //It will return true if that e-mail is available
        else{return true;}
    }

    public boolean checkAvbUser(String user){
        //We just want to read from database!
        SQLiteDatabase db = getReadableDatabase();
        //The Query I want to execute!
        Cursor cursor = db.rawQuery("Select * from accounts where username=?",new String[]{user});
        //This will check if there was a result, it will return false, meaning it's already in use!
        if (cursor.getCount()>0){return false;}
        //It will return true if that e-mail is available
        else{return true;}
    }


    //Verify If Proper LogIn!
    public boolean validateLogIn (String username, String password){
        SQLiteDatabase db = getReadableDatabase();
        //I want to execute the following query
        Cursor cursor = db.rawQuery("Select * from accounts where username=? and password=?",new String[]{username,password});
        if(cursor.getCount()>0){return true;}
        else{return false;}
    }

    //Useless method, keeping it for now!
    public int fetchUserId(String username){
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("Select * from accounts where username=?",new String[]{username});
        //I should only have one result!
        //I now want to just return the users ID!
        if(cursor.moveToFirst()) {
            int x = cursor.getInt(0);
            return x;
        }
        else{
            return -1;
        }

    }


    //Retrieve Entire Cursor Data
    public Cursor retrieveData (String username){
        SQLiteDatabase db = getReadableDatabase();
        return db.rawQuery("Select * from accounts where username=?",new String[]{username});
    }





    //Retrieve Data Individually Methods !

    public String getCurrentFirstName(String username){
        SQLiteDatabase db = getReadableDatabase();
        Cursor data = db.rawQuery("Select * from accounts where username=?",new String[]{username});
        if(data.moveToFirst()){
            return data.getString(3);
        }

        return "error";
    }


    public String getCurrentLastName (String username){
        SQLiteDatabase db = getReadableDatabase();
        Cursor data = db.rawQuery("Select * from accounts where username=?",new String[]{username});
        if(data.moveToFirst()){
            return data.getString(4);
        }

        return "error";
    }


    public String getCurrentPhone (String username){
        SQLiteDatabase db = getReadableDatabase();
        Cursor data = db.rawQuery("Select * from accounts where username=?",new String[]{username});
        if(data.moveToFirst()){
            return data.getString(5);
        }
        return "error";
    }

    public String getCurrentAddress (String username){
        SQLiteDatabase db = getReadableDatabase();
        Cursor data = db.rawQuery("Select * from accounts where username=?",new String[]{username});
        if(data.moveToFirst()){
            return data.getString(6);
        }
        return "error";
    }

    public String getCurrentEmail (String username){
        SQLiteDatabase db = getReadableDatabase();
        Cursor data = db.rawQuery("Select * from accounts where username=?",new String[]{username});
        if(data.moveToFirst()){
            return data.getString(7);
        }
        return "error";
    }


    public String getCurrentType (String username){
        SQLiteDatabase db = getReadableDatabase();
        Cursor data = db.rawQuery("Select * from accounts where username=?",new String[]{username});
        if(data.moveToFirst()){
            return data.getString(8);
        }
        return "error";
    }

}






