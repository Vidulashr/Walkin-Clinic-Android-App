package com.example.walkinclinic;

public class User {
    private String username;
    private String firstName;
    private String phoneNumber;
    private String address;
    private String lastName;
    private String email;

    public User(){ }

    public User(String user, String name, String last, String phone, String addy, String email){
        this.username = user;
        this.firstName = name;
        this.phoneNumber = phone;
        this.address = addy;
        this.lastName = last;
        this.email = email;
    }


    public String getUsername(){ return username; }
    public String getFirstName(){ return firstName; }
    public String getPhoneNumber(){ return phoneNumber; }
    public String getAddress(){ return address; }
    public String getLastName(){ return lastName; }
    public String getEmail(){ return email; }

    //Will be overwritten!
    public String getRole() {
        return "";
    }
}
